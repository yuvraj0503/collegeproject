 setTimeout(function(){
       // $('.flexslider').flexslider();

    },500)